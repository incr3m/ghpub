import{r as t,a as e,t as n}from"./index-bcfaa842.js";function u(r,a){t(2,arguments);var s=n(a);return e(r,-s)}export{u as s};
