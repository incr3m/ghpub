import{r as t,a as d,t as n}from"./index-bcfaa842.js";function u(a,r){t(2,arguments);var e=n(r),s=e*7;return d(a,s)}export{u as a};
