import{e as r}from"./_baseForOwn-9b89c4b6.js";var u=r;function e(a,s){return u(a,s)}var l=e;export{l as i};
