import{a as r,c as t,i as s}from"./_baseForOwn-9b89c4b6.js";var a=r,e=t,g=s,n="[object String]";function o(i){return typeof i=="string"||!e(i)&&g(i)&&a(i)==n}var c=o;export{c as i};
