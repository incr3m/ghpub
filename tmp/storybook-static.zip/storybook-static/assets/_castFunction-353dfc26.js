import{d as n}from"./_baseForOwn-9b89c4b6.js";var i=n;function o(t){return typeof t=="function"?t:i}var c=o;export{c as _};
