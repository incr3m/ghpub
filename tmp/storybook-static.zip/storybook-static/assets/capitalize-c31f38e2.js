import{t}from"./_baseForOwn-9b89c4b6.js";import{n as i}from"./papaparse.min-b66e70e7.js";var a=t,o=i;function p(r){return o(a(r).toLowerCase())}var s=p;export{s as c};
