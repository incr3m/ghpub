var s=(a=>(a.valuation="valuation",a.sales="sales",a))(s||{});export{s as L};
