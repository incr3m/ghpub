import{j as n}from"./TransitionGroupContext-9d36972e.js";import{B as a}from"./Button-352c3435.js";import"./index-f1f749bf.js";import"./_commonjsHelpers-042e6b4d.js";import"./assertThisInitialized-ad1db8e7.js";const c={title:"LAWD/User List Properties",component:a},r={render:()=>n.jsx(a,{variant:"outlined",color:"primary",children:"Add Property"})};var t,o,e;r.parameters={...r.parameters,docs:{...(t=r.parameters)==null?void 0:t.docs,source:{originalSource:`{
  render: () => <Button variant="outlined" color="primary">
      Add Property
    </Button>
}`,...(e=(o=r.parameters)==null?void 0:o.docs)==null?void 0:e.source}}};const u=["Default"];export{r as Default,u as __namedExportsOrder,c as default};
