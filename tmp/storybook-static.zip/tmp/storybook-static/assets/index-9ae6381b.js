import{r as t,t as a}from"./index-bcfaa842.js";import{a as o}from"./index-61adb48a.js";function u(r,e){t(2,arguments);var s=a(e);return o(r,-s)}export{u as s};
