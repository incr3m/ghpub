var a=!0,o="Invariant failed";function c(i,r){if(!i){if(a)throw new Error(o);var n=typeof r=="function"?r():r,t=n?"".concat(o,": ").concat(n):o;throw new Error(t)}}export{c as i};
