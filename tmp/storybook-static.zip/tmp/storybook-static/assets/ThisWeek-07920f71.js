import{j as e}from"./TransitionGroupContext-9d36972e.js";import{R as u,r as R}from"./index-f1f749bf.js";import{f as N,J as Z,c as B,b as me,s as ne,a as ie,K as ve,q as we,C as Se}from"./index-bcfaa842.js";import{d as $e,U as De,P as He}from"./ProjectSelect-6c06b3ef.js";import{s as re}from"./index-9ae6381b.js";import{J as Ee}from"./pick-dba65392.js";import{F as te,m as A,A as Pe,h as pe,B as n,P as ue,at as he,bZ as Oe,b_ as M,i as W,b$ as O,T as I,bx as J,g as Q,bG as Ne,cL as Me,V as U,X as K,ch as Ve,au as We,av as Ae,cM as qe,a8 as xe,C as Re,cN as ae,bJ as le,f as Fe,z as G,bN as Y}from"./papaparse.min-b66e70e7.js";import{H as ze,P as _e,R as fe,ac as Be,ad as Ue,A as E,v as P,b as Le,p as Ze,o as je}from"./Play-87fed129.js";import{S as Ke,a as Je,g as X,t as Qe,b as Ge}from"./Stop-d43309a7.js";import{L as ge}from"./VewJobDetails.story-c6ae2e88.js";import{d as oe}from"./ExpandMore-79a3c159.js";import{d as ce}from"./ExpandLess-3302d2ff.js";import{T as Ye}from"./Trash-822e65ce.js";import{E as be}from"./SortUpIcon-3aecf5f0.js";import{H as z,T as Xe}from"./index-66552ec6.js";import{O as ee}from"./OpportunityLink-b32d0c35.js";import{P as ye,u as et}from"./ProjectLink-987015ba.js";import{b as Ce,c as H,a as tt,d as st}from"./TableRow-00aadd87.js";import{T as nt}from"./TableHead-dd1583ce.js";import{h as it}from"./react-router-19e5b27c.js";import{B as F}from"./Button-352c3435.js";import{U as rt}from"./filter-f99df4e5.js";import{a as at}from"./Save-b67fa0ac.js";import{g as lt}from"./_baseForOwn-9b89c4b6.js";import"./assertThisInitialized-ad1db8e7.js";import"./_commonjsHelpers-042e6b4d.js";import"./index-96c5f47c.js";import"./isNativeReflectConstruct-05c29d01.js";import"./index-61adb48a.js";import"./iframe-ed7f5a3f.js";import"../sb-preview/runtime.js";import"./useGetProjectSummaryFields-0ab32aca.js";import"./SelectEsModelInput-d580a9f7.js";import"./Link-c687dc07.js";import"./react-router-dom-60ea8218.js";import"./tiny-invariant-dd7d57d2.js";import"./_arrayIncludes-2cfb33ae.js";import"./useIncludeFieldNames-35a180a9.js";import"./index-147ad7aa.js";import"./Add-be7f5660.js";import"./uniq-0d482d7b.js";import"./isPlainObject-07477f89.js";import"./debounce-213cd46f.js";import"./index-4d501b15.js";import"./cloneDeep-91467704.js";import"./LocalizationProvider-a287304f.js";import"./index-72884e22.js";import"./index-356e4a49.js";import"./stories-1f769a10.js";import"./index-63a3e378.js";import"./index.esm-bf21a293.js";import"./index-ce960f89.js";import"./index-f70ce446.js";import"./zod-575fe4a8.js";import"./userGroups-edff3f7b.js";import"./SyncEagleDevTool-4c34bdb8.js";import"./searchUsers-04324aeb.js";import"./find-8750f979.js";import"./index-18188c67.js";import"./useFetchMore-be228481.js";import"./useTagSearch-f4fcfbe9.js";import"./Skeleton-cd6f071e.js";import"./uniqBy-baac1626.js";import"./RemoveCircle-617bdac2.js";import"./index-b769406f.js";import"./DragIndicator-582939ba.js";import"./capitalize-c31f38e2.js";import"./isString-2f2f79c0.js";import"./Person-5be09a1e.js";import"./times-069ea398.js";import"./_castFunction-353dfc26.js";import"./TaskForm-863cdb73.js";import"./RepeatFields-8275ed19.js";import"./useBeforeSave-e049f6dd.js";import"./Alert-fd9a067a.js";import"./TaskAssignees-858ea3c9.js";import"./useTaskAssignees-9f1fd5d3.js";import"./github-91d085b0.js";import"./index-9d3afdfc.js";import"./index-79afbab1.js";import"./Check-78df5e8e.js";import"./bundle-053bdffd.js";import"./MilestoneIcon-61fb6e69.js";import"./index-5d349c56.js";import"./EstimateEditorPopover-b8debf9a.js";import"./AssigneeEditorPopover-2b4e6473.js";import"./ToggleButtonGroup-93d9af56.js";import"./index-71ed01a9.js";import"./index-4d31058a.js";import"./Undo-33c7aa7a.js";import"./camelCase-4e7e8b23.js";import"./AuditLogsNoBreadCrumbs-8da9c0ce.js";import"./ExpenseView-2f5d1473.js";import"./MenuOptions-0bc3bb51.js";import"./MultipleSelectFieldInput-d0cee4a2.js";import"./LocationBeFormBody-c033b2b3.js";import"./reduce-4f6f1985.js";function ot(t){return e.jsx(te,{...t,width:"20",height:"19",viewBox:"0 0 20 19",paths:["M5.02944 15.1166C6.35276 16.2886 8.09329 17.0002 10 17.0002C11.9067 17.0002 13.6473 16.2886 14.9706 15.1166C14.7267 14.2396 12.9745 13.6668 10 13.6668C7.02552 13.6668 5.27334 14.2396 5.02944 15.1166ZM3.83376 13.7707C4.77164 12.5319 6.97551 12.0002 10 12.0002C13.0245 12.0002 15.2284 12.5319 16.1663 13.7707C17.0072 12.5588 17.5 11.087 17.5 9.50016C17.5 5.35803 14.1421 2.00016 10 2.00016C5.85787 2.00016 2.50001 5.35803 2.50001 9.50016C2.50001 11.087 2.99283 12.5588 3.83376 13.7707ZM10 18.6668C4.9374 18.6668 0.833344 14.5628 0.833344 9.50016C0.833344 4.43755 4.9374 0.333496 10 0.333496C15.0626 0.333496 19.1667 4.43755 19.1667 9.50016C19.1667 14.5628 15.0626 18.6668 10 18.6668ZM6.66668 7.8335C6.66668 5.96329 7.98259 4.50016 10 4.50016C12.0118 4.50016 13.3333 6.10148 13.3333 8.00016C13.3333 10.7332 11.8484 12.0002 10 12.0002C8.13406 12.0002 6.66668 10.6896 6.66668 7.8335ZM8.33334 7.8335C8.33334 9.72454 9.01519 10.3335 10 10.3335C10.9814 10.3335 11.6667 9.74882 11.6667 8.00016C11.6667 6.95884 11.0131 6.16683 10 6.16683C8.94479 6.16683 8.33334 6.84668 8.33334 7.8335Z"]})}function ct(t){return e.jsx(te,{...t,paths:["M26.6667 9.66667V5.29167H23.7501V6.75001H20.8334V5.29167H9.16675V6.75001H6.25008V5.29167H3.33341V9.66667H26.6667ZM26.6667 12.5833H3.33341V27.1667H26.6667V12.5833ZM23.7501 2.37501H26.6667C28.2776 2.37501 29.5834 3.68084 29.5834 5.29167V27.1667C29.5834 28.7775 28.2776 30.0833 26.6667 30.0833H3.33341C1.72258 30.0833 0.416748 28.7775 0.416748 27.1667V5.29167C0.416748 3.68084 1.72258 2.37501 3.33341 2.37501H6.25008V0.916672H9.16675V2.37501H20.8334V0.916672H23.7501V2.37501ZM10.6251 18.4167H7.70841V15.5H10.6251V18.4167ZM16.4584 18.4167H13.5417V15.5H16.4584V18.4167ZM22.2917 18.4167H19.3751V15.5H22.2917V18.4167ZM10.6251 24.25H7.70841V21.3333H10.6251V24.25ZM16.4584 24.25H13.5417V21.3333H16.4584V24.25Z"]})}const dt=A(()=>({}));function mt({includeCurrent:t,onChange:s,value:a,classes:r,disableUnderline:m,InputProps:l,disableClearable:i}){const d=dt(),p=u.useMemo(()=>{const h=t?new Date:re(new Date,1);return Ee({start:re(h,7),end:h},{weekStartsOn:1}).map(o=>{const T=N(o,"PP"),C=N(Z(o,{weekStartsOn:1}),"PP");return{label:`${T} - ${C}`,id:o.toLocaleDateString("en-se").substring(0,10)}})},[t]),[f,y]=u.useState(()=>p.find(h=>h.id===a));return e.jsx(Pe,{disableClearable:i,classes:r,className:d.root,autoComplete:!0,autoHighlight:!0,options:p,getOptionLabel:h=>h.label,value:f,onChange:(h,c)=>{s({target:{value:(c==null?void 0:c.id)||""}}),y(c)},renderInput:h=>e.jsx(pe,{...h,style:{minWidth:"300px"},label:"Week",fullWidth:!0,variant:"standard",InputProps:{...h.InputProps,...l,disableUnderline:m}})})}function Te(t){return e.jsx(te,{...t,width:"18",height:"17",viewBox:"0 0 18 17",paths:["M15.6667 5.1665V2.6665H14V3.49984H12.3333V2.6665H5.66667V3.49984H4V2.6665H2.33333V5.1665H15.6667ZM15.6667 6.83317H2.33333V15.1665H15.6667V6.83317ZM14 0.999837H15.6667C16.5871 0.999837 17.3333 1.74603 17.3333 2.6665V15.1665C17.3333 16.087 16.5871 16.8332 15.6667 16.8332H2.33333C1.41286 16.8332 0.666667 16.087 0.666667 15.1665V2.6665C0.666667 1.74603 1.41286 0.999837 2.33333 0.999837H4V0.166504H5.66667V0.999837H12.3333V0.166504H14V0.999837ZM6.5 10.1665H4.83333V8.49984H6.5V10.1665ZM9.83333 10.1665H8.16667V8.49984H9.83333V10.1665ZM13.1667 10.1665H11.5V8.49984H13.1667V10.1665ZM6.5 13.4998H4.83333V11.8332H6.5V13.4998ZM9.83333 13.4998H8.16667V11.8332H9.83333V13.4998Z"]})}const pt=A({root:{borderRadius:"12px"}});function L({children:t,paperClassName:s,paperStyle:a,...r}){const m=pt();return e.jsx(n,{...r,children:e.jsx(ue,{className:B(m.root,s),style:a,children:t})})}const ut=A({tableRow:{"& path":{fill:"unset"},"&:hover":{backgroundColor:"#F3F7FB","& path":{fill:"url(#paint0_linear)"}}},playIcon:{width:"18px",height:"18px"},editIcon:{width:"15px",height:"15px"},textColor:{color:"#151D27 !important"},tableCell:{padding:0,paddingRight:"0 !important"},textCenter:{textAlign:"center"},ellipse:{maxWidth:"250px",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}});function ht({interval:t}){var C,v,k,b,D,j,w,x,g,$,S;const s=ut(),{globalState:{authUser:a}}=he(),{startCurrentInterval:r,stopCurrentInterval:m,stopInterval:l}=u.useContext(Oe);let i=t.targetId,d,p,f=null,y,h=null,c;t.targetType===M.Project.resultType?(i=(C=t.project)==null?void 0:C.id,h=(v=t.project)==null?void 0:v.color):t.targetType===M.Opportunity.resultType?(d=(k=t.opportunity)==null?void 0:k.name,i=(b=t.opportunity)==null?void 0:b.id,y=`/sales/opportunity/${i}/activities`):t.targetType===M.Task.resultType?(i=(D=t.task)==null?void 0:D.id,y=`/project/${t.task.projectId}/sprint/${t.task.taskSprintId}/tasks/${t.task.id}`,d=(j=t.task)==null?void 0:j.title,f=(w=t.task)==null?void 0:w.code,p=(x=t.task.project)==null?void 0:x.id,h=(g=t.task.project)==null?void 0:g.color):c=!0,console.log(">>DaysIntervals/IntervalRow::","interval",t);const o=ze({model:t.targetType,id:t.targetId,skip:!c}),{enqueueSnackbar:T}=me();return e.jsxs(Ce,{className:s.tableRow,children:[e.jsx(H,{className:s.tableCell,children:e.jsxs(n,{display:"flex",alignItems:"center",justifyContent:"center",children:[e.jsx(n,{mr:1,children:t.stoppedAt?e.jsx(W,{size:"small",onClick:()=>{var V;(V=t==null?void 0:t.task)!=null&&V.estimatedEffort||T("Please set an Estimated Effort on your current interval.",{variant:"warning"}),r({targetId:i,targetType:t.targetType,interval:t})},children:e.jsx(_e,{size:"small",className:s.playIcon,gradient:!0})}):e.jsx(W,{size:"small",color:"primary",onClick:()=>{t.userId===a.id?m():l(t)},children:e.jsx(Ke,{size:"small",className:s.playIcon})})}),e.jsx(W,{size:"small",onClick:()=>{O.publish("intervalFormDialogOpen",{intervalId:t.id})},children:e.jsx(be,{className:s.editIcon,gradient:!0})})]})}),e.jsx(H,{className:B(s.tableCell,s.textCenter),children:N(t.startedAtMs,"p")}),e.jsx(H,{className:B(s.tableCell,s.textCenter),children:t.stoppedAt?N(t.stoppedAtMs,"p"):"Running"}),e.jsx(H,{className:B(s.tableCell,s.textCenter),children:e.jsx(z,{ms:Je(t.totalHours),style:{minWidth:"80px",display:"inline-block"}})}),e.jsx(H,{children:e.jsx(fe,{to:(($=o==null?void 0:o.metadata)==null?void 0:$.link)||y,className:s.textColor,children:e.jsx(Xe,{noTypography:!0,code:f,title:d||((S=o==null?void 0:o.metadata)==null?void 0:S.display),noWrap:!0,color:h})})}),e.jsx(H,{children:e.jsx(xt,{targetType:t.targetType,targetId:p||t.targetId,dynamicTargetData:o})}),e.jsx(H,{children:t.comment}),e.jsx(H,{className:s.tableCell,children:e.jsx(n,{display:"flex",justifyContent:"center",children:e.jsx(W,{size:"small",onClick:()=>{O.publish("intervalDelete",t)},children:e.jsx(Ye,{size:"small"})})})})]})}function xt({targetType:t,targetId:s,dynamicTargetData:a}){var r;switch(t){case M.Opportunity.resultType:return e.jsx(ee,{id:s});case M.OppItem.resultType:return e.jsx(ee,{id:(r=a==null?void 0:a.record)==null?void 0:r.opportunityId});case M.Project.resultType:case M.Task.resultType:return e.jsx(ye,{id:s})}return null}const ft=u.memo(ht),jt=A({table:{"& th":{textAlign:"center","& span":{fontWeight:"bold"}},"& td":{border:"1px solid #d0d1d5",color:"#151D27 !important"}},tableHeadTitle:{color:"#697D92",textTransform:"uppercase",fontSize:"10px",fontWeight:"bold",textAlign:"center",padding:0}});function gt({daysTotal:t,day:s,setCurrentInterval:a}){const r=jt();return u.useMemo(()=>{const m=t.find(l=>l.day===s);return a&&a(m),m.intervals.length?e.jsxs(tt,{size:"small",className:r.table,fixedHeader:!1,children:[e.jsx(nt,{children:e.jsxs(Ce,{children:[e.jsx(H,{style:{width:"65px",minWidth:"65px"},className:r.tableHeadTitle,children:"actions"}),e.jsx(H,{style:{width:"70px",minWidth:"70px"},className:r.tableHeadTitle,children:"start"}),e.jsx(H,{style:{width:"70px",minWidth:"70px"},className:r.tableHeadTitle,children:"end"}),e.jsx(H,{style:{width:"45px",minWidth:"45px"},className:r.tableHeadTitle,children:"hours"}),e.jsx(H,{className:r.tableHeadTitle,style:{width:"300px"},children:"task"}),e.jsx(H,{style:{width:"220px"},className:r.tableHeadTitle,children:"project"}),e.jsx(H,{className:r.tableHeadTitle,children:"comment"}),e.jsx(H,{style:{width:"40px",minWidth:"40px"}})]})}),e.jsx(st,{children:m.intervals.map(l=>e.jsx(ft,{interval:l},l.id))})]}):e.jsx(n,{display:"flex",justifyContent:"center",alignItems:"center",p:10,children:e.jsx(I,{children:"No intervals on this day."})})},[t,s,r])}async function bt(t,s,a){var r,m,l;try{const i=await J.query({query:Q`
        query searchTimesheets(
          # $userId: ID!
          $filter: SearchableTimesheetFilterInput
          $sort: SearchableTimesheetSortInput
        ) {
          searchTimesheets(filter: $filter, sort: $sort) {
            total
            items {
              archived
              week
              userId
              comments
              createdAt
              createdBy
              id
              recEditors
              recOwner
              recViewers
              status
              updatedAt
              updatedBy
            }
          }
        }
      `,variables:{sort:{direction:"desc"},filter:{week:{match:t}}}}),d=(l=(m=(r=i==null?void 0:i.data)==null?void 0:r.searchTimesheets)==null?void 0:m.items)==null?void 0:l.find(y=>(y==null?void 0:y.userId)===a);console.log({filterByCurrentUser:d}),await J.mutate({mutation:Q`
        mutation updateTimesheet($input: UpdateTimesheetInput!) {
          updateTimesheet(input: $input) {
            createdAt
            comments
            archived
            updatedBy
            userId
            week
            status
            id
            recViewers
            recOwner
            recEditors
            updatedAt
          }
        }
      `,variables:{input:{id:d==null?void 0:d.id,week:d==null?void 0:d.week,userId:d==null?void 0:d.userId,status:s}}});const f=Ne({subject:"New Pending Timesheet Approval",message:"A user has sumbitted their timesheet for approval",link:"/timesheets/for-approval",toUserId:a,recOwner:a,__typename:"Notification",__op:"create",__fields:"recOwner toUserId subject message"});await J.mutate({mutation:Q`
        mutation(
          ${f.args}
        ) {
          ${f.body}
        }
      `,variables:{...f==null?void 0:f.vars}}),console.log({res:i,filterByCurrentUser:d}),console.log("Success updating timesheet")}catch(i){console.log("Failed to update timesheet",i)}}const yt=A({activeTab:{background:"linear-gradient(270deg, #FA126C 0%, #FF9F4B 100%) !important"},borderWrapper:{padding:"1px",background:"#E6E9ED",borderRadius:"12px",marginRight:"10px","&:last-child":{marginRight:0}},tabBtn:{border:"none",background:"#fff",outline:"none",cursor:"pointer",padding:0,height:"120px",width:"120px",display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center",borderRadius:"12px"},dayTitle:{fontWeight:"bold",fontSize:"12px",letterSpacing:" 0.05em",textTransform:"uppercase"},dayDate:{color:"#697D92",fontSize:"12px"},daysWithButton:{display:"flex",alignItems:"center"},daysWithComments:{display:"flex",alignItems:"flex-start",justifyContent:"space-between"},submitButton:{display:"flex",alignItems:"flex-start",height:100,marginLeft:20}});function Ct({daysTotal:t,week:s,status:a}){var T;const[r,m]=u.useState(()=>X()),[l,i]=u.useState({}),{enqueueSnackbar:d}=me(),p=yt(),f=ne(new Date(s),{weekStartsOn:0}),y=u.useCallback(()=>{var C;O.publish("intervalFormDialogOpen",{stoppedAt:(C=l==null?void 0:l.intervals[0])==null?void 0:C.stoppedAt,activeDate:ie(f,r)})},[l.intervals,f,r]),h=it(),{globalState:{authUser:c}}=he(),o=u.useMemo(()=>{if(!t)return;const C=[],v=ne(new Date(s),{weekStartsOn:1});return t.forEach((k,b)=>{k&&C.push(e.jsx("div",{className:B([p.borderWrapper,{[p.activeTab]:r===k.day}]),children:e.jsxs("button",{className:p.tabBtn,onClick:()=>{m(k.day)},children:[e.jsx(I,{className:p.dayTitle,children:Me[k.day]}),e.jsx(I,{className:p.dayDate,children:N(ie(v,b),"PP")}),console.log({value:k==null?void 0:k.id,data:k}),e.jsx(U,{label:`${Qe(k.value)} h`,size:"small"})]})}))}),e.jsx(n,{mb:4,display:"flex",justifyContent:"space-between",alignItems:"center",children:e.jsx(n,{mb:4,display:"flex",justifyContent:"flex-start",children:C})})},[t,p,r]);return e.jsxs(e.Fragment,{children:[e.jsxs(n,{className:p.daysWithButton,children:[e.jsx(n,{children:o}),e.jsxs(n,{className:p.submitButton,children:[console.log({authUser:c}),((T=h.pathname)==null?void 0:T.includes("my-week"))&&e.jsx(F,{onClick:()=>{bt(s,"submitted",c==null?void 0:c.id).then(()=>{d("Timesheet Submitted Successfully!",{variant:"success"}),window.location.reload()}),console.log({week:s,authUser:c})},disabled:a==="approved"||a==="rejected"||a==="submitted",variant:"contained",color:"primary",children:"Submit Times"})]})]}),e.jsx(n,{mb:2,children:e.jsx(K,{title:"Create interval",children:e.jsx(W,{color:"inherit",size:"small",onClick:y,children:e.jsx($e,{})})})}),e.jsx(gt,{daysTotal:t,day:r,setCurrentInterval:C=>i(C)})]})}function ke({color:t="#37516D",className:s}){return e.jsx("svg",{className:s,width:"28",height:"28",viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e.jsx("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M5.39262 6.5H9V9H1.5V1.48901H4V4.32056C6.79635 1.3882 9.98328 0.25 14 0.25C21.5939 0.25 27.75 6.40608 27.75 14C27.75 21.5939 21.5939 27.75 14 27.75C6.40608 27.75 0.25 21.5939 0.25 14H2.75C2.75 20.2132 7.7868 25.25 14 25.25C20.2132 25.25 25.25 20.2132 25.25 14C25.25 7.7868 20.2132 2.75 14 2.75C10.449 2.75 7.80582 3.73922 5.39262 6.5ZM15.25 12.75H20.25V15.25H12.75V6.5H15.25V12.75Z",fill:t})})}const Tt=A(({spacing:t})=>({percentBar:{borderRight:"1px solid #000",position:"relative","&:last-child":{borderRight:0}},percentBarInner:{width:"100%",height:"100%",position:"absolute",top:0,left:0,"&:hover":{transform:"scale(1.02, 1.5)",zIndex:1}},popupArrow:{width:0,height:0,borderLeft:"10px solid transparent",borderRight:"10px solid transparent",borderBottom:"10px solid #37516D",position:"absolute",content:"''",bottom:"-19px",left:"calc(50% - 10px)",transform:"translate(0, -50%)"},popup:{backgroundColor:"#37516D",padding:t(2),borderRadius:"6px",color:"#fff",fontSize:"12px",position:"relative",marginTop:"12px"},projectTitle:{fontWeight:"600"},projectSubtitle:{fontWeight:"500"},numIntervals:{color:"rgba(255, 255, 255, 0.7)"},timeIcon:{width:"13.75px",height:"13.75px"}}));function kt({project:t,color:s}){const a=Tt(),[r,m]=u.useState(!1),l=u.useRef(),i=u.useCallback(()=>{m(!0)},[]),d=u.useCallback(()=>{m(!1)},[]);return e.jsxs(e.Fragment,{children:[e.jsxs(n,{p:.5,className:a.percentBar,style:{backgroundColor:s,width:t.percent?`${t.percent}%`:"0%"},children:[e.jsx(n,{className:a.percentBarInner,style:{backgroundColor:s},ref:l,onMouseOver:i,onMouseOut:d}),e.jsx(n,{className:a.popupArrow,style:{display:r?"block":"none"}})]}),e.jsx(Ve,{open:r,anchorEl:l.current,children:e.jsxs(n,{className:a.popup,children:[e.jsx(I,{className:a.projectTitle,children:t.name}),e.jsxs(n,{display:"flex",className:a.projectSubtitle,children:[e.jsx(I,{children:t.percent?`${Number(t.percent).toFixed(2)}%`:"0%"}),e.jsx(n,{mr:2}),e.jsxs(n,{display:"flex",alignItems:"center",children:[e.jsx(ke,{className:a.timeIcon,color:"#CDD3DB"}),e.jsx(n,{mr:1}),e.jsx(z,{ms:t.totalTimeMs})]})]}),e.jsxs(I,{className:a.numIntervals,children:[t.numIntervals," intervals"]})]})})]})}const It=u.memo(kt);var se={},vt=Ae;Object.defineProperty(se,"__esModule",{value:!0});var Ie=se.default=void 0,wt=vt(We()),St=e;Ie=se.default=(0,wt.default)((0,St.jsx)("path",{d:"M20 4v13.17L18.83 16H4V4zm0-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4V4c0-1.1-.9-2-2-2m-2 10H6v2h12zm0-3H6v2h12zm0-3H6v2h12z"}),"InsertCommentOutlined");const $t=({comment:t,onSubmit:s,onDelete:a,showActionButtons:r})=>{var h,c,o,T,C;const[m,l]=R.useState(!1),[i,d]=R.useState({fullname:"",profilePhoto:"",comment:null,open:!1,isDeleting:!1}),p=v=>{v.preventDefault(),s(i==null?void 0:i.comment),l(!1)},f=v=>{d(k=>({...k,comment:v.target.value}))};R.useEffect(()=>{d(v=>({...v,comment:t}))},[t]);const y=u.useCallback(async()=>{const v=await Be.graphql(Ue(`
            query ($id: ID!) {
              getUser (id: $id) {
                id
                fullname
                profilePhoto
              }
            }
          `,{id:i.comment.userId})),{fullname:k,profilePhoto:b}=v.data.getUser;d(D=>({...D,fullname:k,profilePhoto:b}))},[(h=i.comment)==null?void 0:h.userId]);return R.useEffect(()=>{y()},[y]),e.jsxs(n,{mb:3,style:{display:"flex",justifyContent:"space-between",alignItems:"flex-start"},children:[e.jsxs(n,{children:[e.jsxs(n,{style:{display:"flex",alignItems:"flex-start"},children:[e.jsx(rt,{variant:"rounded",s3Key:i.profilePhoto,size:"small"}),e.jsxs(n,{ml:1,children:[e.jsx(I,{variant:"button",mx:1,children:i==null?void 0:i.fullname}),e.jsx(I,{variant:"caption",style:{color:"#697D92"},children:((c=i.comment)==null?void 0:c.date)&&N(new Date((o=i.comment)==null?void 0:o.date),"dd/MM/yyyy hh:mm")})]})]}),!m&&e.jsx(I,{ml:6,children:(T=i.comment)==null?void 0:T.message}),m&&e.jsxs(n,{ml:6,children:[e.jsx(pe,{value:i.comment.message,onChange:f,margin:"dense",variant:"outlined",fullWidth:!0}),e.jsx(F,{variant:"outlined",style:{marginRight:"8px"},onClick:()=>l(!1),children:"Cancel"}),e.jsx(F,{variant:"contained",color:"primary",onClick:p,children:"Update"})]})]}),!m&&r&&e.jsxs(n,{style:{display:"flex",justifyContent:"flex-end",alignItems:"center"},children:[e.jsx(n,{mr:1,children:e.jsx(K,{title:"Edit comment",children:e.jsx(W,{size:"small",onClick:()=>l(!0),children:e.jsx(be,{})})})}),e.jsx(n,{className:"rdg-actions",children:e.jsx(K,{title:"Delete Comment",placement:"left",children:e.jsx(W,{size:"small",children:e.jsx(at,{onClick:a})})})})]})]},(C=i.comment)==null?void 0:C.id)},Dt=({timesheet:t,onSubmit:s,onCancel:a,onDelete:r,showActionButtons:m})=>{var p,f,y;const[l,i]=R.useState({data:[],newComment:""}),d=h=>{h.preventDefault(),s(l.newComment)};return R.useEffect(()=>{i(h=>({...h,data:t}))},[t]),e.jsxs(n,{m:3,style:{width:"500px"},children:[e.jsx(n,{style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:e.jsx(I,{variant:"h6",children:"COMMENT"})}),((p=l==null?void 0:l.data)==null?void 0:p.comments)&&e.jsx(n,{mt:4,children:e.jsx($t,{comment:(f=l.data)!=null&&f.comments?JSON.parse(l.data.comments):"",onSubmit:s,onDelete:r,showActionButtons:m})}),!((y=l==null?void 0:l.data)!=null&&y.comments)&&e.jsxs(e.Fragment,{children:[e.jsx(n,{mt:4,children:e.jsx(qe,{placeholder:"Write a comment",style:{width:"100%",color:"#37516D",borderRadius:4,fontSize:13},value:l.newComment,onChange:h=>{i(c=>({...c,newComment:h.target.value}))}})}),e.jsxs(n,{mt:2,style:{display:"flex",justifyContent:"flex-end",alignItems:"center"},children:[e.jsx(F,{variant:"outlined",onClick:a,style:{marginRight:"8px"},children:"Cancel"}),e.jsx(F,{variant:"contained",onClick:d,children:"Add Comment"})]})]})]})},Ht=({isOpen:t,onClose:s,isDeleting:a,onDelete:r})=>{const m=u.useCallback(async()=>{r(""),s()},[s,r]);return e.jsx(xe,{open:t,onClose:s,children:e.jsx(n,{p:2,children:a?e.jsx(Re,{size:30}):e.jsxs(e.Fragment,{children:[e.jsx(I,{variant:"h6",mb:3,children:"DELETE COMMENT"}),e.jsx(I,{children:"Are you sure you want to delete the comment?"}),e.jsxs(n,{mt:2,display:"flex",justifyContent:"flex-end",children:[e.jsx(n,{mr:2,children:e.jsx(F,{color:"secondary",size:"small",onClick:s,children:"Cancel"})}),e.jsx(F,{color:"primary",variant:"contained",size:"small",onClick:m,children:"Confirm"})]})]})})})},Et=`
id
week
status
comments
userId
`,Pt=({week:t,userId:s,timesheetUserId:a,showActionButtons:r=!0})=>{const[m,l]=R.useState({submitting:!1,isDialogOpen:!1,isConfirmationOpen:!1,isDeleting:!1,timesheet:{}}),i=u.useCallback(async()=>{var c,o;let h=await E.graphql(P(`query ($filter: SearchableTimesheetFilterInput) {
            searchTimesheets (filter: $filter) {
              items {
                ${Et}
              }
            }
          }`,{filter:{week:{matchPhrase:t},userId:{eq:a}}}));h=(o=(c=h.data)==null?void 0:c.searchTimesheets)==null?void 0:o.items[0],console.log("currentTimehsst",h),l(T=>({...T,timesheet:h}))},[a,t]);u.useEffect(()=>{i()},[i]);const d=u.useCallback(async h=>{l(C=>({...C,submitting:!0}));const o={userId:s,message:h,date:new Date};await E.graphql(P(`mutation ($input: UpdateTimesheetInput!) {
                updateTimesheet (input: $input) {
                id
                },
            }`,{input:{id:m.timesheet.id,comments:JSON.stringify(o)}}))&&l(C=>({...C,submitting:!1})),i()},[i,m.timesheet.id,s]),p=u.useCallback(()=>{l({...m,isDialogOpen:!1})},[m]),f=u.useCallback(()=>{l({...m,isConfirmationOpen:!0})},[m]),y=u.useCallback(async()=>{await E.graphql(P(`mutation ($input: UpdateTimesheetInput!) {
                  updateTimesheet (input: $input) {
                    id
                  },
                }`,{input:{id:m.timesheet.id,comments:null}}))&&(i(),l(c=>({...c,submitting:!1,isConfirmationOpen:!1,isDialogOpen:!1})))},[i,m.timesheet.id]);return e.jsxs(n,{children:[e.jsx(K,{title:m.timesheet.comments?"View Comment":"Add Comment",children:e.jsx(Ie,{onClick:()=>l({...m,isDialogOpen:!0})})}),e.jsx(xe,{open:m.isDialogOpen,onClose:p,children:e.jsx(n,{p:1,children:e.jsx(Dt,{timesheet:m.timesheet,onSubmit:d,onCancel:p,onDelete:f,showActionButtons:r})})}),e.jsx(Ht,{isOpen:m.isConfirmationOpen,isDeleting:m.isDeleting,onDelete:y,onClose:()=>l(h=>({...h,isConfirmationOpen:!1}))})]})},de=`
  id
  userId
  task {
    id
    title
    code
    projectId
    taskSprintId
    estimatedEffort
    project {
      id
      name
      color
    }
  }
  project {
    id
    name
    color
  }
  opportunity {
    id
    name
  }
  opportunityId
  targetType
  targetId
  comment
  startedAt
  stoppedAt
  startedAtMs
  stoppedAtMs
  isDone
  isTagged
  durationMs
  totalHours
  timezone
  week
  day
  forProjectId
`,Ot=A(({spacing:t})=>({projectsTotal:{display:"flex",alignItems:"center",padding:t(2.5),paddingLeft:0,paddingRight:0,marginLeft:t(5),marginRight:t(5),borderTop:"1px solid #F4F5F7","&:first-child":{borderTop:0}},title:{fontSize:"14px"},subtitle:{color:"#697D92"},sectionTitle:{fontWeight:"bold",marginBottom:t(2)},timeIcon:{color:"#CDD3DB",width:"13.75px",height:"13.75px"},projectColorIndicatorContainer:{borderRadius:"100%",marginRight:t(1),padding:"3px"},projectColorIndicator:{padding:t(1),borderRadius:"100%"},textEllipsis:{textOverflow:"ellipsis",overflow:"hidden",fontWeight:"bold",whiteSpace:"nowrap"}}));function Nt({userId:t,week:s,projectId:a}){var h;const r=Ot();let m=null,l=null;const[i,d]=u.useState({fetched:!1,weekTotal:null,projectsTotal:null,daysTotal:null,status:null,comment:null}),p=u.useCallback(async()=>{var o,T;let c=await E.graphql(P(`query ($filter: SearchableTimesheetFilterInput) {
        searchTimesheets (filter: $filter) {
          items {
            status
            comments
          }
        }
      }`,{filter:{week:{matchPhrase:s},userId:{eq:t}}}));c=(T=(o=c.data)==null?void 0:o.searchTimesheets)==null?void 0:T.items[0],d(C=>({...C,status:(c==null?void 0:c.status)||"Ongoing",comment:c==null?void 0:c.comments}))},[t,s]);u.useEffect(()=>{p()},[p]);const f=u.useCallback(async()=>{const c={userId:{eq:t},startedAtMs:{gte:ve(new Date(s)).getTime()}};a&&(c.forProjectId={eq:a});const o=await E.graphql(P(`query ($filter: SearchableIntervalFilterInput) {
        searchIntervals (
          limit: 999
          filter: $filter
        ) {
          items {
            ${de}
          }
        }
      }`,{filter:c})),T=[],C=o.data.searchIntervals.items.reduce((x,g,$)=>{var _;const S=[M.Project.resultType,M.Opportunity.resultType].includes(g.targetType);let q=`WEEK::${g.forProjectId||(S?g.opportunityId:(_=g.task)==null?void 0:_.projectId)}::${t}::${s}`;return S&&(q=`OPPORTUNITY::${q}`),T.includes(q)?x:(T.push(q),`
          ${x}
          q${$}: getIntervalReport(id: "${q}") {
            id
            value
            task {
              estimatedEffort
            }
            project {
              id
              name
              color
            }
            opportunity {
              id
              name
            }
          }
        `)},"");let v="",k="";Object.keys(ae).forEach(x=>{const g=ae[x],$=a?`day::${g}::${a}::${t}::${s}`:`day::${g}::${t}::${s}`;v=`
          ${v}
          r${g}: getIntervalReport(id: "${$}") {
            id
            value
          }
        `,k=`
          ${k}
          i${g}: searchIntervals (
            sort: {
              field: startedAt,
              direction: desc
            }
            filter: {
              day: { eq: "${g}" }
              week: { matchPhrase: "${s}" }
              userId: { eq: "${t}" }
              ${a?`forProjectId: { eq: "${a}" }`:""}
            }
            limit: 999
          ) {
            items {
              ${de}
            }
          }
        `});const[b,D,j,w]=await Promise.all([E.graphql(P(`query ($id: ID!) {
          getIntervalReport(id: $id) {
            id
            value
          }
        }`,{id:a?`WEEK::TOTAL::${a}::${s}`:`WEEK::TOTAL::${t}::${s}`})),C.length?E.graphql(P(`{ ${C} }`)):null,v.length?E.graphql(P(`{ ${v} }`)):null,k.length?E.graphql(P(`{ ${k} }`)):null]);d(x=>({...x,fetched:!0,weekTotal:b.data.getIntervalReport,projectsTotal:D?Object.keys(D.data).map(g=>D.data[g]):null,daysTotal:j?Object.keys(j.data).map(g=>{const $=j.data[g],S=w.data[g.replace("r","i")].items||[];return $?{...$,day:Number(g.replace("r","")),intervals:S}:{id:g,day:Number(g.replace("r","")),value:0,intervals:S}}):null}))},[a,t,s]);u.useEffect(()=>{d({fetched:!1,weekTotal:null,projectsTotal:null,daysTotal:null}),f()},[s,t,a,f]),u.useEffect(()=>{const c=O.subscribe("intervalStarted",(k,{interval:b,user:D})=>{D.id===t&&d(j=>({...j,daysTotal:j.daysTotal.map(w=>w.day!==X()?w:{...w,intervals:[b].concat(w.intervals)})}))}),o=O.subscribe("intervalStopped",(k,{interval:b,user:D})=>{D.id===t&&d(j=>{var w;return{...j,weekTotal:{...j.weekTotal,value:(((w=j.weekTotal)==null?void 0:w.value)||0)+b.durationMs},projectsTotal:j.projectsTotal?j.projectsTotal.map(x=>{var $,S,V;if(!x)return x;const g=b.targetType===M.Opportunity.resultType?b.opportunity.id:($=b.task)==null?void 0:$.projectId;return(((S=x.project)==null?void 0:S.id)||((V=x.opportunity)==null?void 0:V.id))!==g?x:{...x,value:x.value+b.durationMs}}):null,daysTotal:j.daysTotal?j.daysTotal.map(x=>x.day!==X()?x:{...x,value:x.value+b.durationMs,intervals:x.intervals.map(g=>g.id!==b.id?g:b)}):null}})}),T=le.listen("intervalEdited",()=>{setTimeout(f,1e3)}),C=O.subscribe("intervalComment",()=>{setTimeout(f,1e3)}),v=O.subscribe("intervalDeleted",(k,b)=>{d(D=>({...D,weekTotal:{...i.weekTotal,value:i.weekTotal.value-b.durationMs},projectsTotal:i.projectsTotal.map(j=>{var g,$;if(!j)return;const w=j.project?(g=j.project)==null?void 0:g.id:($=j.opportunity)==null?void 0:$.id,x=b.task?b.task.projectId:b.opportunity.id;return w!==x?j:{...j,value:j.value-b.durationMs}}),daysTotal:i.daysTotal.map(j=>{const w=j.intervals.filter(x=>x.id!==b.id);return{...j,value:w.length<j.intervals.length?j.value-b.durationMs:j.value,intervals:w}})})),setTimeout(f,2e3)});return()=>{O.unsubscribe(c),O.unsubscribe(o),le.remove(T),O.unsubscribe(v),O.unsubscribe(C)}},[i.daysTotal,i.projectsTotal,i.weekTotal,t,f]);const y=u.useMemo(()=>i.projectsTotal?i.projectsTotal.map(c=>{if(!c)return null;const o=c.project||c.opportunity;return e.jsxs(n,{className:r.projectsTotal,children:[e.jsx(n,{mr:4,children:e.jsx(U,{label:e.jsx(z,{ms:c.value}),size:"small"})}),e.jsx(I,{className:r.title,children:c.opportunity?e.jsx(ee,{id:o==null?void 0:o.id}):e.jsx(ye,{id:o==null?void 0:o.id})})]},c.id)}):null,[i.projectsTotal,r]);if(!i.fetched)return e.jsx(ge,{});if(i.projectsTotal){m=[],l=[];const c=(h=i==null?void 0:i.weekTotal)==null?void 0:h.value;i.projectsTotal.forEach(o=>{var T,C,v,k;if(console.log(o),(T=o==null?void 0:o.project)!=null&&T.id){let b=0,D=0;const j=[];i.daysTotal.forEach($=>{console.log("interval value",$),$.intervals.forEach(S=>{var V,q,_;S.forProjectId===((V=o==null?void 0:o.project)==null?void 0:V.id)&&(b++,j.indexOf((q=S==null?void 0:S.task)==null?void 0:q.id)==-1&&(j.push((_=S==null?void 0:S.task)==null?void 0:_.id),D++))})});const w=o.value/c*100,x={id:(C=o==null?void 0:o.project)==null?void 0:C.id,percent:w,name:(v=o==null?void 0:o.project)==null?void 0:v.name,totalTimeMs:o==null?void 0:o.value,numIntervals:b,numTasks:D},g=(k=o.project)!=null&&k.color?o.project.color:"#cccccc";m.push(e.jsx(It,{project:x,color:g})),l.push(e.jsxs(n,{mt:2,mr:2,mb:2,display:"flex",alignItems:"center",children:[e.jsx(ue,{className:r.projectColorIndicatorContainer,children:e.jsx(n,{className:r.projectColorIndicator,style:{backgroundColor:g}})}),e.jsxs(n,{style:{maxWidth:"200px"},children:[e.jsxs(n,{display:"flex",children:[e.jsx(fe,{to:`/project/${x.id}`,children:e.jsx(n,{className:r.textEllipsis,style:{maxWidth:"150px"},children:x.name})}),e.jsx("span",{style:{color:"#37516D",marginLeft:"4px"},children:x.percent?`${x.percent.toFixed(2)}%`:"0%"})]}),e.jsxs(n,{display:"flex",alignItems:"center",children:[e.jsx(ke,{className:r.timeIcon,color:"#CDD3DB"}),e.jsx(n,{mr:.5}),e.jsx(z,{ms:x.totalTimeMs,style:{flexShrink:0}}),e.jsx(n,{mr:1}),e.jsx(n,{mr:1,children:e.jsxs(I,{variant:"caption",className:r.textEllipsis,style:{maxWidth:"80px"},children:[x.numIntervals," ",x.numIntervals===1?e.jsx(u.Fragment,{children:"interval"}):e.jsx(u.Fragment,{children:"intervals"})]})}),e.jsx(n,{mr:1,children:e.jsxs(I,{variant:"caption",className:r.textEllipsis,style:{maxWidth:"80px"},children:[x.numTasks," ",x.numTasks===1?e.jsx(u.Fragment,{children:"task"}):e.jsx(u.Fragment,{children:"tasks"})]})})]})]})]}))}})}return e.jsxs(e.Fragment,{children:[e.jsxs(n,{mb:7,children:[e.jsx(I,{className:r.sectionTitle,children:"By Projects"}),e.jsx(L,{mb:.6,children:e.jsxs(n,{pr:5,display:"flex",justifyContent:"space-between",alignItems:"center",children:[e.jsxs(n,{p:2.5,pl:5,pr:5,display:"flex",alignItems:"center",children:[e.jsx(n,{mr:4,children:e.jsx(U,{label:e.jsx(z,{ms:i.weekTotal?i.weekTotal.value:0}),size:"small"})}),e.jsx(n,{mr:2,display:"flex",alignItems:"center",children:e.jsx(Te,{})}),e.jsx(I,{className:r.title,children:e.jsxs("span",{className:r.subtitle,children:[e.jsx("strong",{children:N(new Date(s),"EEEE")}),","," ",N(new Date(s),"PPP"),e.jsx(n,{component:"span",mr:2,ml:2,children:"-"}),e.jsx("strong",{children:N(Z(new Date(s),{weekStartsOn:1}),"EEEE")}),", ",N(Z(new Date(s),{weekStartsOn:1}),"PPP")]})})]}),e.jsxs(n,{display:"flex",alignItems:"center",children:[e.jsxs(n,{display:"flex",alignItems:"center",children:[e.jsx(I,{children:"Status:"}),e.jsx(U,{label:i.status,size:"small"})]}),i.status==="rejected"&&i.comment&&e.jsx(n,{pt:1,children:e.jsx(Pt,{week:s,timesheetUserId:t,showActionButtons:!1})})]})]})}),console.log(y),m?e.jsx(n,{mt:2,mb:2,children:e.jsx(L,{children:e.jsxs(n,{p:2,children:[e.jsx(I,{className:r.sectionTitle,children:"PROJECTS OVERVIEW"}),e.jsx(n,{mt:3,mb:3,display:"flex",children:m}),e.jsx(n,{p:2,display:"flex",alignItems:"center",flexWrap:"wrap",justifyContent:"space-between",style:{border:"1px solid #CDD3DB",borderRadius:"12px"},children:l})]})})}):null]}),e.jsxs(n,{mb:2,children:[e.jsx(I,{className:r.sectionTitle,children:"By Days"}),e.jsx(L,{children:e.jsx(n,{p:2,children:e.jsx(Ct,{daysTotal:i.daysTotal,week:s,status:i.status})})})]})]})}const Mt=A(t=>({root:{marginBottom:t.spacing(.5)},content:{padding:t.spacing(1),display:"flex",alignItems:"center",justifyContent:"space-between"},row:{display:"flex",alignItems:"center","& > div":{display:"flex",alignItems:"center"}},sub:{fontSize:"smaller",fontWeight:"bold",color:t.palette.primary.dark,"& svg":{color:t.palette.primary.main,marginRight:t.spacing(1),height:20,opacity:.3}}}));function Vt({user:t,week:s,projectId:a}){const[r,m]=u.useState({isOpen:!1,openedBefore:!1,status:""}),l=Mt(),i=we(),d=u.useCallback(()=>{m(y=>({isOpen:!y.isOpen,openedBefore:!0}))},[]),p=u.useCallback(async()=>{const y=`
      id
      week
      status
    `;let h=await E.graphql(P(`query ($filter: SearchableTimesheetFilterInput) {
        searchTimesheets (filter: $filter) {
          items {
            ${y}
          }
        }
      }`,{filter:{week:{matchPhrase:s},userId:{eq:t.id}}}));return h=h.data.searchTimesheets.items[0],h.status||(console.log(`Intervals: >> creating new timesheet for ${s}`),h=(await E.graphql(P(`mutation ($input: CreateTimesheetInput!) {
          createTimesheet (input: $input) {
            ${y}
          }
        }`,{input:{week:s,userId:t.id,status:"Pending"}}))).data.createTimesheet),m(c=>({...c,status:h.status})),h},[t.id,s]);u.useEffect(()=>{p()},[p]);const f=u.useMemo(()=>r.openedBefore?e.jsx(Nt,{userId:t.id,week:s,projectId:a}):null,[r.openedBefore,t.id,s,a]);return e.jsxs("div",{className:l.root,children:[e.jsx(L,{children:e.jsxs(n,{className:l.content,children:[e.jsxs("div",{className:l.row,children:[e.jsx(n,{width:"20px",children:e.jsx(W,{size:"small",onClick:d,children:r.isOpen?e.jsx(ce,{}):e.jsx(oe,{})})}),e.jsx(n,{width:"150px",justifyContent:"space-evenly",children:e.jsx(U,{label:e.jsx(z,{ms:t.weekTotal}),size:"small"})}),e.jsx(n,{width:"300px",children:e.jsx(Le,{member:t,color:i.palette.primary.dark})}),e.jsxs(n,{width:"150px",className:l.sub,children:[e.jsx(ct,{}),t.dayCount||"0"," Days"]}),e.jsxs(n,{width:"150px",className:l.sub,children:[e.jsx(Ze,{}),t.taskCount||"0"," Tasks"]}),e.jsxs(n,{width:"150px",className:l.sub,children:[e.jsx(je,{}),t.projectCount||"0"," Projects"]}),e.jsx(n,{width:"150px",className:l.sub,children:(r==null?void 0:r.status)||"Ongoing"})]}),e.jsx(W,{size:"small",onClick:d,children:r.isOpen?e.jsx(ce,{}):e.jsx(oe,{})})]})}),e.jsx(Se,{in:r.isOpen,children:e.jsx(n,{p:2,children:f})})]})}function Wt(t=[],s){const[a,r]=u.useState({}),{startDate:m,endDate:l}=u.useMemo(()=>{const d=new Date(s),p=Z(d,{weekStartsOn:1});return{startDate:d,endDate:p}},[s]),i=Fe({index:"interval",skip:!t||t.length<1,body:{size:0,query:{bool:{must:[{range:{startedAt:{gte:m,lte:l}}},{bool:{should:(t||[]).map(({id:d})=>({term:{"userId.keyword":d}}))}}]}},aggs:{group_by_member:{terms:{field:"userId.keyword"},aggs:{group_by_day:{date_histogram:{field:"startedAt",interval:"day"}},group_by_task:{terms:{field:"taskId.keyword"}},group_by_project:{terms:{field:"forProjectId.keyword"}}}}}}});return console.log(">>TeamWeekView/useUserSubDetails::","esQ",i),u.useEffect(()=>{const d={};for(const p of lt(i,"result.aggregations.group_by_member.buckets",[]))d[p.key]={dayCount:p.group_by_day.buckets.length,taskCount:p.group_by_task.buckets.length,projectCount:p.group_by_project.buckets.length};r(d)},[i]),a}const At=A(()=>({header:{display:"flex",alignItems:"center",marginBottom:20,marginLeft:10,"& > div":{display:"flex",alignItems:"center",fontWeight:"bold",float:"left",letterSpacing:"0.75px",color:"#697D92"},"& .MuiTypography-button":{fontSize:"smaller"}}}));function qt({week:t,userId:s,projectId:a}){const[r,m]=u.useState(null),l=At();u.useEffect(()=>{async function p(){m(null);let f;s?f=[(await E.graphql(P(`
            query ($id: ID!) {
              getUser(id: $id) {
                id
                fullname
                profilePhoto
              }
            }
          `,{id:s}))).data.getUser]:f=(await E.graphql(P(`query($filter: SearchableUserFilterInput){
          searchUsers (filter: $filter, limit: 999) {
            items {
              id
              fullname
              profilePhoto
            }
          }
        }`,{filter:{status:{ne:"In-active"}}}))).data.searchUsers.items;let y="";f.forEach((c,o)=>{const T=a?`WEEK::${a}::${c.id}::${t}`:`WEEK::TOTAL::${c.id}::${t}`;y+=`
          q${o}: getIntervalReport (id: "${T}") {
            id
            value
          }
        `});const h=await E.graphql(P(`{ ${y} }`));m(f.map((c,o)=>{var T;return{...c,weekTotal:((T=h.data[`q${o}`])==null?void 0:T.value)||0}}))}p()},[t,s,a]);const i=Wt(r,t),d=u.useMemo(()=>r?r.map(p=>e.jsx(Vt,{user:{...p,...i[p.id]},week:t,projectId:a},p.id)):e.jsx(ge,{}),[r,t,a,i]);return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:l.header,children:[e.jsx(n,{width:"20px"}),e.jsx(n,{width:"150px",justifyContent:"center",children:e.jsx(I,{variant:"button",children:e.jsx("strong",{children:"Total Time"})})}),e.jsx(n,{width:"300px",justifyContent:"center",children:e.jsx(I,{variant:"button",children:e.jsx("strong",{children:"Team member"})})}),e.jsx(n,{width:"150px",children:e.jsx(I,{variant:"button",children:e.jsx("strong",{children:"Days"})})}),e.jsx(n,{width:"150px",children:e.jsx(I,{variant:"button",children:e.jsx("strong",{children:"Tasks"})})}),e.jsx(n,{width:"150px",children:e.jsx(I,{variant:"button",children:e.jsx("strong",{children:"Projects"})})}),e.jsx(n,{width:"150px",children:e.jsx(I,{variant:"button",children:e.jsx("strong",{children:"Status"})})})]}),d]})}function Hn({hideTitle:t,userOnly:s}){const[a,r]=u.useState(()=>({selectedWeek:N(Ge(),"y-MM-dd"),selectedUserId:s||"",selectedProjectId:""}));console.log("selected user",s),et({paths:[{label:"",link:"/"},{label:"Timesheets",link:"/timesheets"},{label:"This Week",link:"/timesheets/this-week"}]});const m=u.useCallback(({target:{value:d}})=>{r(p=>({...p,selectedProjectId:d}))},[]),l=u.useCallback(({target:{value:d}})=>{r(p=>({...p,selectedWeek:d}))},[]),i=u.useCallback(({target:{value:d}})=>{console.log(d,s),r(p=>({...p,selectedUserId:d}))},[s]);return e.jsxs(e.Fragment,{children:[!t&&e.jsx(n,{display:"flex",alignItems:"center",justifyContent:"space-between",mb:3,mt:3,children:e.jsx(I,{variant:"h1",sx:{textTransform:"uppercase",fontSize:20,fontWeight:"bold"},children:"THIS WEEK"})}),e.jsxs(n,{mb:5,display:"flex",children:[e.jsx(G,{mr:1,width:"320px",containerProps:{padding:"15px"},children:e.jsx(n,{sx:{marginTop:"0px","& label":{marginTop:"-5px"}},children:e.jsx(mt,{includeCurrent:!0,value:a.selectedWeek,onChange:l,disableUnderline:!0,disableClearable:!0,InputProps:{startAdornment:e.jsx(Y,{position:"start",children:e.jsx(Te,{})})}})})}),!s&&e.jsx(G,{mr:1,containerProps:{padding:"15px"},children:e.jsx(n,{sx:{marginTop:"0px","& label":{marginTop:"-5px"}},children:e.jsx(De,{value:a.selectedUserId,onChange:i,disableUnderline:!0,label:"Team member",enableAllOptions:!0,disableClearable:!0,InputProps:{startAdornment:e.jsx(Y,{position:"start",children:e.jsx(ot,{})})}})})}),e.jsx(G,{mr:1,containerProps:{padding:"15px"},children:e.jsx(n,{sx:{marginTop:"0px","& label":{marginTop:"-5px"}},children:e.jsx(He,{value:a.selectedProjectId,onChange:m,disableUnderline:!0,enableAllOptions:!0,InputProps:{startAdornment:e.jsx(Y,{position:"start",children:e.jsx(je,{})})}})})})]}),e.jsx(qt,{week:a.selectedWeek,userId:a.selectedUserId,projectId:a.selectedProjectId})]})}export{Hn as default};
