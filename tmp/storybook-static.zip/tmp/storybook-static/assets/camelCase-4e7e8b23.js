import{c as t}from"./capitalize-c31f38e2.js";import{_ as c}from"./papaparse.min-b66e70e7.js";var o=t,m=c,i=m(function(e,a,r){return a=a.toLowerCase(),e+(r?o(a):a)}),n=i;export{n as c};
